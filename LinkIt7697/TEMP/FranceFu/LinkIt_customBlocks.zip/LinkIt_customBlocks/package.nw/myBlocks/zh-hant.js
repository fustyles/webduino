Blockly.Msg.digitalWrite = "數位寫入";
Blockly.Msg.digitalRead = "數位讀取";