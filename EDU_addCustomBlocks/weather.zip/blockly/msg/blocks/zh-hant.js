﻿Blockly.Msg.ADDCUSTOMBLOCKS_SHOW = "自訂積木";
