Blockly.Msg.ADDCUSTOMBLOCKS_SHOW = "Custom Blocks";
