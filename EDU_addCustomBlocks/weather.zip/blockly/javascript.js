Blockly.JavaScript['addCustomBlocks'] = function (block) {
  var code = '';
  return code; 
};
