MSG.catBasicPackage = "基礎套件包";
